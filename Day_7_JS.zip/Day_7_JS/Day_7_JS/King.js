type="text/javascript">
			function alertFun(){
				alert('Do Not Use Mobile Phones');
			}


			